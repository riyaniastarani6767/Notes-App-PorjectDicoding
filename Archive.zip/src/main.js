// // src/main.js

import "./styles/main.css";
import { render } from "./routers/router.js";

window.addEventListener("load", render);
