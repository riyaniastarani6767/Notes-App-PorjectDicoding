// // ================== VERSION & CACHE ==================
// const VERSION = "v1.0.2";
// const STATIC_CACHE = `static-${VERSION}`;
// const RUNTIME_CACHE = `runtime-${VERSION}`;

// // App shell (DEV): pastikan file inti ada biar nggak dinosaurus
// const APP_SHELL = [
//   "/",
//   "/index.html",
//   "/offline.html",
//   "/src/main.js",
//   "/src/styles/main.css",
// ];

// // ================== INSTALL / ACTIVATE ==================
// self.addEventListener("install", (event) => {
//   event.waitUntil(caches.open(STATIC_CACHE).then((c) => c.addAll(APP_SHELL)));
//   self.skipWaiting(); // ambil alih lebih cepat
// });

// self.addEventListener("activate", (event) => {
//   event.waitUntil(
//     (async () => {
//       const keys = await caches.keys();
//       await Promise.all(
//         keys
//           .filter((k) => ![STATIC_CACHE, RUNTIME_CACHE].includes(k))
//           .map((k) => caches.delete(k))
//       );
//     })()
//   );
//   self.clients.claim(); // kontrol semua tab
// });

// // ================== FETCH HANDLERS ==================
// self.addEventListener("fetch", (event) => {
//   const req = event.request;
//   if (req.method !== "GET") return;

//   if (req.mode === "navigate") {
//     // Navigasi SPA: network-first → cache → offline.html
//     event.respondWith(handleNavigation(req));
//     return;
//   }

//   const url = new URL(req.url);
//   const isAPI =
//     /\/stories/i.test(url.pathname) || url.pathname.includes("/v1/stories");

//   if (isAPI) {
//     event.respondWith(staleWhileRevalidate(req));
//     return;
//   }

//   // Static assets: cache-first
//   event.respondWith(cacheFirst(req));
// });

// async function handleNavigation(request) {
//   try {
//     const fresh = await fetch(request);
//     return fresh;
//   } catch {
//     const staticCache = await caches.open(STATIC_CACHE);
//     const shell =
//       (await staticCache.match("/index.html")) ||
//       (await staticCache.match("/"));
//     if (shell) return shell;

//     const offline = await staticCache.match("/offline.html");
//     return (
//       offline || new Response("Offline", { status: 503, statusText: "Offline" })
//     );
//   }
// }

// async function staleWhileRevalidate(request) {
//   const cache = await caches.open(RUNTIME_CACHE);
//   const cached = await cache.match(request);

//   const networkPromise = fetch(request)
//     .then((res) => {
//       cache.put(request, res.clone());
//       return res;
//     })
//     .catch(() => undefined);

//   return (
//     cached || (await networkPromise) || new Response("Offline", { status: 503 })
//   );
// }

// async function cacheFirst(request) {
//   const hit = await caches.match(request);
//   if (hit) return hit;

//   try {
//     const res = await fetch(request);
//     const cache = await caches.open(RUNTIME_CACHE);
//     cache.put(request, res.clone());
//     return res;
//   } catch {
//     return new Response("Offline", { status: 503 });
//   }
// }

// // ================== PUSH NOTIFICATIONS (DEBUG ROBUST) ==================
// self.addEventListener("push", (event) => {
//   let data = {};
//   try {
//     if (event.data?.json) {
//       data = event.data.json();
//     } else if (event.data?.text) {
//       try {
//         data = JSON.parse(event.data.text());
//       } catch {
//         data = { body: event.data.text() };
//       }
//     }
//   } catch {
//     data = {};
//   }

//   const title = data.title || "StoryMap";
//   const body = data.body || "Ada update baru.";
//   const icon = data.icon || "/icons/icon-192.png";
//   const url = data.url || "/#/";

//   const options = {
//     body,
//     icon,
//     badge: icon,
//     data: { url },
//     actions: [{ action: "open", title: "Buka" }],
//     requireInteraction: true,
//     silent: false,
//   };

//   event.waitUntil(
//     (async () => {
//       try {
//         console.log("[SW] push received:", data);
//         await self.registration.showNotification(title, options);
//         console.log("[SW] showNotification OK");
//       } catch (err) {
//         console.error("[SW] showNotification ERROR:", err);
//         // fallback: kirim pesan ke semua tab (opsional)
//         const clis = await clients.matchAll({
//           type: "window",
//           includeUncontrolled: true,
//         });
//         for (const c of clis)
//           c.postMessage({ type: "PUSH_FALLBACK", title, body });
//       }
//     })()
//   );
// });

// // ================== CLICK NOTIFICATION ==================
// self.addEventListener("notificationclick", (event) => {
//   const targetUrl = event.notification?.data?.url || "/#/";
//   event.notification.close();

//   event.waitUntil(
//     (async () => {
//       try {
//         const all = await clients.matchAll({
//           type: "window",
//           includeUncontrolled: true,
//         });
//         // cocokan berdasarkan origin scope SW
//         const scopeOrigin = new URL(self.registration.scope).origin;
//         const hit = all.find((c) => new URL(c.url).origin === scopeOrigin);

//         if (hit) {
//           await hit.focus();
//           // navigate kadang tidak tersedia/ditolak; coba, kalau gagal buka window baru
//           try {
//             await hit.navigate(targetUrl);
//           } catch {
//             await clients.openWindow(targetUrl);
//           }
//         } else {
//           await clients.openWindow(targetUrl);
//         }
//       } catch (e) {
//         console.error("[SW] notificationclick ERROR:", e);
//         try {
//           await clients.openWindow(targetUrl);
//         } catch {}
//       }
//     })()
//   );
// });

/* ================== VERSION & CACHE ================== */
const VERSION = "v1.0.8"; // <-- ganti tiap update SW
const STATIC_CACHE = `static-${VERSION}`;
const RUNTIME_CACHE = `runtime-${VERSION}`;

// App shell minimal (aman untuk dev & prod)
const APP_SHELL = ["/", "/index.html", "/offline.html"];

// Domain eksternal yang tidak kita cache (opsional)
const IGNORE_CACHE_HOSTS = ["tile.openstreetmap.org"];

// Helper flag dev
const IS_DEV = self.location.hostname === "localhost";

/* ================== INSTALL / ACTIVATE ================== */
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(STATIC_CACHE).then((c) => c.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => ![STATIC_CACHE, RUNTIME_CACHE].includes(k))
          .map((k) => caches.delete(k))
      );
    })()
  );
  self.clients.claim();
});

/* ================== FETCH HANDLER ================== */
self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Hanya tangani GET
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  const isHttp = url.protocol === "http:" || url.protocol === "https:";

  // Abaikan non-HTTP (mis. chrome-extension://…)
  if (!isHttp) return;

  // Abaikan asset/dev routes Vite saat localhost (HMR, @vite)
  const isViteDevAsset =
    IS_DEV &&
    url.origin === self.location.origin &&
    (url.pathname.startsWith("/@vite") ||
      url.pathname.startsWith("/vite") ||
      url.pathname.includes("hmr") ||
      url.pathname.startsWith("/@react-refresh") ||
      url.pathname.startsWith("/__vite_ping"));

  if (isViteDevAsset) return;

  // Jangan cache domain tertentu (mis. tile peta)
  if (IGNORE_CACHE_HOSTS.some((h) => url.hostname.includes(h))) {
    // biarkan ke network langsung tanpa strategi SW
    return;
  }

  // Navigasi SPA → Network First → Cache → offline.html
  if (req.mode === "navigate") {
    event.respondWith(handleNavigation(req));
    return;
  }

  // Data dinamis API (contoh: /v1/stories) → Stale-While-Revalidate
  const isAPI =
    /\/stories/i.test(url.pathname) || url.pathname.includes("/v1/stories");
  if (isAPI) {
    event.respondWith(staleWhileRevalidate(req));
    return;
  }

  // Static assets default → Cache First
  event.respondWith(cacheFirst(req));
});

async function handleNavigation(request) {
  try {
    return await fetch(request);
  } catch {
    const staticCache = await caches.open(STATIC_CACHE);
    const shell =
      (await staticCache.match("/index.html")) ||
      (await staticCache.match("/"));
    if (shell) return shell;

    const offline = await staticCache.match("/offline.html");
    return (
      offline || new Response("Offline", { status: 503, statusText: "Offline" })
    );
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);

  const url = new URL(request.url);
  const sameOrigin = url.origin === self.location.origin;

  const networkPromise = fetch(request)
    .then((res) => {
      // cache hanya jika same-origin & response OK
      if (sameOrigin && res && res.ok) {
        cache.put(request, res.clone());
      }
      return res;
    })
    .catch(() => undefined);

  return (
    cached || (await networkPromise) || new Response("Offline", { status: 503 })
  );
}

async function cacheFirst(request) {
  const hit = await caches.match(request);
  if (hit) return hit;

  const url = new URL(request.url);
  const sameOrigin = url.origin === self.location.origin;

  try {
    const res = await fetch(request);
    if (sameOrigin && res && res.ok) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(request, res.clone());
    }
    return res;
  } catch {
    return new Response("Offline", { status: 503 });
  }
}

/* ================== PUSH NOTIFICATIONS ================== */
// Basic (+2 pts) — tampil dari DevTools/Server
self.addEventListener("push", (event) => {
  let data = {};
  try {
    if (event.data?.json) {
      data = event.data.json();
    } else if (event.data?.text) {
      try {
        data = JSON.parse(event.data.text());
      } catch {
        data = { body: event.data.text() };
      }
    }
  } catch {
    data = {};
  }

  const title = data.title || "StoryMap";
  const options = {
    body: data.body || "Ada update baru.",
    icon: data.icon || "/icons/icon-192.png",
    badge: data.badge || "/icons/badge-72.png",
    data: { url: data.url || "/#/" },
    actions: [{ action: "open", title: "Buka" }],
    requireInteraction: true,
    silent: false,
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification?.data?.url || "/#/";

  event.waitUntil(
    (async () => {
      const all = await clients.matchAll({
        type: "window",
        includeUncontrolled: true,
      });
      const scopeOrigin = new URL(self.registration.scope).origin;
      const hit = all.find((c) => new URL(c.url).origin === scopeOrigin);

      if (hit) {
        await hit.focus();
        try {
          await hit.navigate(targetUrl);
          return;
        } catch {}
      }
      await clients.openWindow(targetUrl);
    })()
  );
});
