// src/pages/home.js
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { apiGetStories } from "../api/story.js";
import { addFavorite } from "../scripts/utils/db.js";

// Perbaikan ikon marker saat bundle Vite
import iconRetinaUrl from "leaflet/dist/images/marker-icon-2x.png";
import iconUrl from "leaflet/dist/images/marker-icon.png";
import shadowUrl from "leaflet/dist/images/marker-shadow.png";
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({ iconRetinaUrl, iconUrl, shadowUrl });

export default {
  async render() {
    return `
      <section class="card" aria-labelledby="home-title">
        <h1 id="home-title">Beranda</h1>

        <div id="map"
             style="height:360px; border-radius:12px; margin-bottom:12px"
             aria-label="Peta lokasi story"></div>

        <ul id="storyList"
            class="story-list"
            aria-live="polite"
            style="list-style:none; padding:0; margin:0; display:grid; gap:12px">
          <li role="status" aria-busy="true" class="card" style="padding:12px; border-radius:12px">
            Memuat data...
          </li>
        </ul>
      </section>
    `;
  },

  async afterRender() {
    /* -------------------- MAP -------------------- */
    const map = L.map("map", { zoomControl: true }).setView([-2.5, 118], 4);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);

    const listEl = document.getElementById("storyList");
    let items = [];

    /* -------------------- FETCH -------------------- */
    try {
      const res = await apiGetStories();
      items = Array.isArray(res) ? res : res?.list ?? [];
    } catch (err) {
      console.error("[home] apiGetStories error:", err);
      listEl.innerHTML = `
        <li role="status" class="card" style="padding:12px; border-radius:12px">
          Gagal memuat data
        </li>`;
      return;
    }

    /* -------------------- RENDER (SEKALI SAJA) -------------------- */
    listEl.innerHTML = items
      .map((s, i) => {
        const title = s.name || s.title || `Story #${i + 1}`;
        const desc = s.description || "";
        const time = s.createdAt ? new Date(s.createdAt).toLocaleString() : "";

        const lat = s.lat ?? s.latitude ?? s?.location?.lat ?? null;
        const lon = s.lon ?? s.lng ?? s.longitude ?? s?.location?.lng ?? null;

        if (typeof lat === "number" && typeof lon === "number") {
          try {
            L.marker([lat, lon]).addTo(map).bindPopup(title);
          } catch (e) {
            console.warn("gagal add marker:", e);
          }
        }

        const img =
          s.photoUrl || s.imageUrl || s.url || s?.photo || s?.image || "";
        const imgHtml = img
          ? `<img src="${img}" alt="Foto '${title}'"
                   style="width:56px;height:56px;border-radius:12px;object-fit:cover;background:#eee" loading="lazy">`
          : `<div style="width:56px;height:56px;border-radius:12px;background:#eee"></div>`;

        return `
          <li class="card" style="padding:12px; border-radius:12px">
            <div style="display:flex; gap:12px; align-items:flex-start">
              ${imgHtml}
              <div style="flex:1; min-width:0">
                <h3 style="margin:0 0 4px; font-size:1rem; line-height:1.25">${title}</h3>
                ${time ? `<small style="opacity:.7">${time}</small>` : ""}
                ${
                  desc
                    ? `<p style="margin:6px 0 0; white-space:pre-wrap">${desc}</p>`
                    : ""
                }
              </div>
              <div style="display:flex; gap:8px">
                <button type="button"
                        class="btn btn-primary"
                        data-save
                        data-idx="${i}"
                        aria-label="Simpan story ${title}">
                  Simpan
                </button>
              </div>
            </div>
          </li>
        `;
      })
      .join("");

    /* -------------------- HANDLER (EVENT DELEGATION) -------------------- */
    if (!listEl.__BOUND__) {
      listEl.__BOUND__ = true;
      listEl.addEventListener("click", async (e) => {
        const btn = e.target.closest("[data-save]");
        if (!btn) return;

        const idx = Number(btn.dataset.idx);
        const item = items[idx];
        if (!item) return;

        const prevText = btn.textContent;
        btn.disabled = true;
        btn.textContent = "Menyimpan...";

        try {
          await addFavorite(item); // simpan ke IndexedDB
          btn.textContent = "Tersimpan";
        } catch (err) {
          console.error("[home] addFavorite error:", err);
          btn.textContent = prevText;
          btn.disabled = false;
          alert("Gagal menyimpan. Coba lagi.");
        }
      });
    }
  },
};
