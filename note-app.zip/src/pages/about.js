export default {
  async render() {
    return `
      <div class="card">
        <h2>Tentang</h2>
        <p>StoryMap adalah contoh aplikasi SPA sederhana dengan routing hash.</p>
      </div>
    `;
  },
  async afterRender() {},
};
