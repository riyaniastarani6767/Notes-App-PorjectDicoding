// src/pages/favorites.js
import { idbGetAll, idbDelete } from "../scripts/utils/db.js";

export default {
  async render() {
    return `
      <section class="card" aria-labelledby="fav-title">
        <h1 id="fav-title">Favorit</h1>
        <p class="muted">Daftar cerita yang kamu simpan ke perangkat (IndexedDB).</p>
        <ul id="favList" style="list-style:none; padding:0; margin:12px 0 0 0"></ul>
        <p id="favMsg" role="status" style="margin-top:8px"></p>
      </section>
    `;
  },

  async afterRender() {
    const listEl = document.getElementById("favList");
    const msgEl = document.getElementById("favMsg");

    msgEl.textContent = "Memuat favorit dari perangkat...";
    try {
      const items = await idbGetAll("saved"); // READ
      if (!items.length) {
        msgEl.textContent = "Belum ada favorit. Simpan dari halaman Beranda.";
        listEl.innerHTML = "";
        return;
      }
      msgEl.textContent = "";

      listEl.innerHTML = items
        .map(
          (s) => `
        <li class="card" style="margin:8px 0;">
          <div style="display:flex;gap:12px;align-items:flex-start">
            <img src="${
              s.photoUrl || ""
            }" alt="" style="width:88px;height:88px;object-fit:cover;border-radius:10px"/>
            <div style="flex:1">
              <div><b>${s.name || "-"}</b> • <small>${
            s.createdAt ? new Date(s.createdAt).toLocaleString() : ""
          }</small></div>
              <div>${s.description || ""}</div>
              ${
                s.lat != null && s.lon != null
                  ? `<small>(${s.lat}, ${s.lon})</small>`
                  : ""
              }
              <div style="margin-top:8px;">
                <button class="btn-outline" data-del="${
                  s.id
                }" aria-label="Hapus dari favorit">Hapus</button>
              </div>
            </div>
          </div>
        </li>
      `
        )
        .join("");

      // DELETE
      listEl.querySelectorAll("[data-del]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const id = btn.getAttribute("data-del");
          await idbDelete("saved", id);
          // re-render cepat
          const li = btn.closest("li");
          li?.parentNode?.removeChild(li);
          if (!listEl.children.length) {
            msgEl.textContent = "Favorit kosong.";
          }
        });
      });
    } catch (e) {
      msgEl.textContent = e?.message || "Gagal membaca favorit.";
    }
  },
};
