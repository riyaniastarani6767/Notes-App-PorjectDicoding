import HomePage from "../pages/home.js";
import AddPage from "../pages/add.js";
import LoginPage from "../pages/login.js";
import RegisterPage from "../pages/register.js";
import AboutPage from "../pages/about.js";
import FavoritePage from "../pages/favorites.js";

import {
  isAuthed,
  getName,
  clearAuth as clearSession,
} from "../scripts/utils/store.js";
import { apiLogout } from "../api/story.js";

const routes = {
  "#/": HomePage,
  "#/add": AddPage,
  "#/login": LoginPage,
  "#/register": RegisterPage,
  "#/about": AboutPage,
  "#/favorites": FavoritePage,
};

const AUTH_REQUIRED = new Set(["#/", "#/add"]);
const AUTH_PAGES = new Set(["#/login", "#/register"]);
const requiresAuth = (h) => AUTH_REQUIRED.has(h);
const isAuthPage = (h) => AUTH_PAGES.has(h);

function navbar() {
  const authed = isAuthed();
  const name = getName();
  return `
    <nav aria-label="Navigasi utama" class="navbar">
      <a href="#/" data-link class="brand">StoryMap</a>
      <a href="#/" data-link>Beranda</a>
      <a href="#/add" data-link>Tambah</a>
      <a href="#/about" data-link>Tentang</a>
      <a href="#/favorites" data-link>Favorit</a>
      <div class="spacer" aria-hidden="true"></div>
      ${
        authed
          ? `<span>Hai, <b>${name}</b></span>
             <button class="btn-outline" data-logout aria-label="Keluar">Keluar</button>`
          : `<a class="btn" href="#/login">Masuk</a>
             <a class="btn-outline" href="#/register">Daftar</a>`
      }
    </nav>
  `;
}
const footer = () =>
  `<footer class="footer">© ${new Date().getFullYear()} StoryMap</footer>`;

let _isRendering = false;
let _rerenderPending = false;

async function _render() {
  if (_isRendering) {
    _rerenderPending = true;
    return;
  }
  _isRendering = true;

  const root = document.getElementById("app");
  const hash = window.location.hash || "#/";

  if (isAuthPage(hash) && isAuthed()) {
    window.location.hash = "#/";
    _isRendering = false;
    return;
  }

  if (requiresAuth(hash) && !isAuthed()) {
    window.location.hash = "#/login";
    _isRendering = false;
    return;
  }

  let Page = routes[hash];
  if (!Page && hash === "#/favorites") {
    try {
      const mod = await import("../pages/favorites.js");
      if (mod?.default) {
        routes["#/favorites"] = mod.default;
        Page = mod.default;
      }
    } catch (e) {
      console.warn("[router] gagal lazy-load favorites:", e);
    }
  }
  Page = Page || AboutPage; // fallback aman

  document.body.classList.toggle("auth", isAuthPage(hash));

  const view = (await Page.render?.()) ?? "";
  if (isAuthPage(hash)) {
    root.innerHTML = view;
  } else {
    root.innerHTML = `
      ${navbar()}
      <main id="main-content" class="container" tabindex="-1">
        ${view}
      </main>
      ${footer()}
    `;
  }

  await Page.afterRender?.();

  const btnLogout = document.querySelector("[data-logout]");
  if (btnLogout && !btnLogout.__BOUND__) {
    btnLogout.__BOUND__ = true;
    btnLogout.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        await apiLogout();
      } finally {
        clearSession();
        window.location.hash = "#/login";
      }
    });
  }

  // Highlight nav aktif
  document.querySelectorAll("nav a[data-link]").forEach((a) => {
    a.classList.toggle("active", a.getAttribute("href") === hash);
  });

  // Aksesibilitas: fokus ke konten utama
  document.getElementById("main-content")?.focus?.();

  _isRendering = false;
  if (_rerenderPending) {
    _rerenderPending = false;
    _render();
  }
}

/* --------------------------- ROUTER SINGLETON --------------------------- */
function bindRouterOnce() {
  const nextHandler = function render() {
    if (!document.startViewTransition) return _render();
    document.startViewTransition(_render);
  };

  // Lepas handler lama (mencegah dobel saat HMR)
  if (window.__ROUTER__?.handler) {
    window.removeEventListener("hashchange", window.__ROUTER__.handler);
    document.removeEventListener("DOMContentLoaded", window.__ROUTER__.handler);
  }
  window.__ROUTER__ = { handler: nextHandler };

  window.addEventListener("hashchange", nextHandler);
  document.addEventListener("DOMContentLoaded", nextHandler);
}
bindRouterOnce();

export { _render as __debugRender };
